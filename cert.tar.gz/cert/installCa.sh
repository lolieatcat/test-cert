rm -rf CA;
mkdir -p CA/{certs,crl,newcerts,private}
touch CA/index.txt
echo 00 > CA/serial
#Create the root key and a root certificate
openssl req -new -x509 -days 36500 -keyout ca.key -out ca.crt -config openssl.cnf
#Create the server key
openssl genrsa -out server.key 2048
#Use the private key to create a certificate signing request 
openssl req -new -key server.key -out server.csr -config openssl.cnf
#Check the signing request
openssl req -text -noout -in server.csr 
#Use the self-sign CA to create the server certificate
openssl ca -in server.csr -out server.crt -cert ca.crt -keyfile ca.key -extensions v3_req -config openssl.cnf
cp server.key server.crt ../conf/